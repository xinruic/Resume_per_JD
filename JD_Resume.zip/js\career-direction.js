const CareerDirectionModule = (function() {
  const STORAGE_KEY = 'career_directions';
  const STORAGE_KEY_SKILLS = 'career_skills';
  
  let directions = [];
  let skills = [];

  function init() {
    loadData();
    renderTags();
    setupEventListeners();
  }

  function loadData() {
    directions = Utils.storage.get(STORAGE_KEY, ['产品经理', 'AI工程师', 'Agent开发']);
    skills = Utils.storage.get(STORAGE_KEY_SKILLS, []);
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, directions);
    if (directions.length > 0) {
      Utils.storage.set(STORAGE_KEY_SKILLS, skills);
    } else {
      Utils.storage.remove(STORAGE_KEY_SKILLS);
    }
  }

  function renderTags() {
    const container = document.getElementById('selectedTags');
    if (!container) return;
    
    container.innerHTML = directions.map(tag => `
      <span class="selected-tag" data-tag="${tag}">
        ${tag}
        <span class="remove-tag" onclick="CareerDirectionModule.removeTag('${tag}')">×</span>
      </span>
    `).join('');
  }

  function addTag(tag) {
    if (!tag || tag.trim() === '') return;
    
    const trimmedTag = tag.trim();
    if (!directions.includes(trimmedTag)) {
      directions.push(trimmedTag);
      saveData();
      renderTags();
      Utils.showToast(`已添加方向: ${trimmedTag}`, 'success');
    }
  }

  function removeTag(tag) {
    const index = directions.indexOf(tag);
    if (index !== -1) {
      directions.splice(index, 1);
      saveData();
      renderTags();
    }
  }

  function setupEventListeners() {
    const input = document.getElementById('careerDirection');
    if (input) {
      input.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
          addTag(input.value);
          input.value = '';
        }
      });
    }

    const analyzeBtn = document.getElementById('analyzeDirectionBtn');
    if (analyzeBtn) {
      analyzeBtn.addEventListener('click', analyzeCareerDirection);
    }
  }

  async function analyzeCareerDirection() {
    if (directions.length === 0) {
      Utils.showToast('请先添加目标岗位方向', 'error');
      return;
    }

    const btn = document.getElementById('analyzeDirectionBtn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '分析中...';

    try {
      const result = await getAIAnalysis(directions);
      displayAnalysisResult(result);
    } catch (error) {
      console.error('AI分析失败:', error);
      Utils.showToast('AI分析失败，请重试', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  }

  async function getAIAnalysis(directions) {
    const prompt = `请分析以下求职方向的核心技能需求：
    
    求职方向：${directions.join('、')}
    
    请为每个方向列出3-5个核心技能标签，并给出简短的分析建议。
    
    返回格式：
    {
      "skills": [
        {"name": "技能名称", "description": "技能描述", "icon": "图标"}
      ],
      "analysis": "综合分析建议"
    }`;

    return new Promise((resolve) => {
      setTimeout(() => {
        const skillMap = {
          '产品经理': [
            { name: '产品思维', description: '用户需求分析与产品规划能力', icon: '🎯' },
            { name: '需求分析', description: '业务需求梳理与功能定义', icon: '📋' },
            { name: '用户体验', description: '产品体验优化与设计', icon: '✨' },
            { name: '数据分析', description: '数据驱动决策能力', icon: '📊' },
            { name: '项目管理', description: '项目进度把控与交付', icon: '📈' }
          ],
          'AI工程师': [
            { name: '机器学习', description: 'ML算法与模型训练', icon: '🤖' },
            { name: '深度学习', description: '神经网络与深度学习框架', icon: '🧠' },
            { name: '数据处理', description: '大规模数据处理与分析', icon: '💾' },
            { name: '模型部署', description: '模型部署与优化', icon: '🚀' },
            { name: '算法优化', description: '算法性能优化', icon: '⚡' }
          ],
          'Agent开发': [
            { name: '智能体架构', description: 'Agent系统架构设计', icon: '🏗️' },
            { name: '多轮对话', description: '对话系统开发', icon: '💬' },
            { name: '工具调用', description: '工具使用与扩展', icon: '🔧' },
            { name: '知识图谱', description: '知识库构建', icon: '🔗' },
            { name: '任务规划', description: '复杂任务分解与规划', icon: '📋' }
          ]
        };

        let allSkills = [];
        directions.forEach(dir => {
          if (skillMap[dir]) {
            allSkills = [...allSkills, ...skillMap[dir]];
          }
        });

        resolve({
          skills: allSkills.slice(0, 8),
          analysis: `针对${directions.join('、')}方向，建议重点突出相关技术栈和项目经验，注重量化成果和实际案例。`
        });
      }, 1000);
    });
  }

  function displayAnalysisResult(result) {
    skills = result.skills || [];
    saveData();

    const bubble = document.getElementById('aiSpriteBubble');
    const content = document.getElementById('aiAnalysisResult');
    const skillsSummary = document.getElementById('skillsSummary');
    const skillsGrid = document.getElementById('skillsGrid');

    if (content) {
      content.innerHTML = `<p>${result.analysis}</p>`;
    }

    if (bubble) {
      bubble.style.display = 'block';
    }

    if (skillsGrid) {
      skillsGrid.innerHTML = skills.map(skill => `
        <div class="skill-item">
          <div class="skill-icon">${skill.icon}</div>
          <div class="skill-name">${skill.name}</div>
          <div class="skill-desc">${skill.description}</div>
        </div>
      `).join('');
    }

    if (skillsSummary) {
      skillsSummary.style.display = 'block';
    }
  }

  function getDirections() {
    return [...directions];
  }

  function getSkills() {
    return [...skills];
  }

  return {
    init,
    addTag,
    removeTag,
    getDirections,
    getSkills
  };
})();

window.CareerDirectionModule = CareerDirectionModule;
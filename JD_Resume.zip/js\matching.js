const MatchingModule = (function() {
  const STORAGE_KEY = 'matching_results';
  
  let matchingResults = {};

  function init() {
    loadData();
    setupEventListeners();
  }

  function loadData() {
    matchingResults = Utils.storage.get(STORAGE_KEY, {});
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, matchingResults);
  }

  function calculateMatching() {
    const experiences = ExperienceModule.getExperiences();
    const jdData = JdAnalysisModule.getJdData();
    const jdKeywords = JdAnalysisModule.getJdKeywords();

    if (experiences.length === 0) {
      Utils.showToast('请先添加简历经历', 'error');
      return;
    }

    if (jdKeywords.length === 0) {
      Utils.showToast('请先在JD解析栏目分析岗位需求', 'error');
      return;
    }

    const results = [];

    experiences.forEach(exp => {
      const score = calculateExperienceScore(exp, jdKeywords);
      const matchedKeywords = findMatchedKeywords(exp, jdKeywords);
      
      results.push({
        experience: exp,
        score: score,
        matchedKeywords: matchedKeywords,
        suggestions: generateSuggestions(exp, jdKeywords, matchedKeywords)
      });
    });

    results.sort((a, b) => b.score - a.score);
    matchingResults = {
      overallScore: calculateOverallScore(results),
      results: results,
      timestamp: Date.now()
    };

    saveData();
    displayResults();
    Utils.showToast('匹配度分析完成', 'success');
  }

  function calculateExperienceScore(exp, keywords) {
    let score = 0;
    const text = (exp.description || '') + ' ' + (exp.skills || '') + ' ' + (exp.role || '') + ' ' + (exp.company || '');
    
    keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        score += 10;
      }
    });

    return Math.min(score, 100);
  }

  function findMatchedKeywords(exp, keywords) {
    const matched = [];
    const text = (exp.description || '') + ' ' + (exp.skills || '') + ' ' + (exp.role || '');
    
    keywords.forEach(keyword => {
      if (text.includes(keyword)) {
        matched.push(keyword);
      }
    });

    return matched;
  }

  function generateSuggestions(exp, allKeywords, matchedKeywords) {
    const suggestions = [];
    const unmatchedKeywords = allKeywords.filter(kw => !matchedKeywords.includes(kw));
    
    unmatchedKeywords.slice(0, 3).forEach(keyword => {
      suggestions.push(`可添加与"${keyword}"相关的描述`);
    });

    return suggestions;
  }

  function calculateOverallScore(results) {
    if (results.length === 0) return 0;
    
    const totalScore = results.reduce((sum, r) => sum + r.score, 0);
    return Math.round(totalScore / results.length);
  }

  function displayResults() {
    const container = document.getElementById('matchingResult');
    if (!container) return;

    const overallScore = matchingResults.overallScore || 0;
    const results = matchingResults.results || [];

    container.innerHTML = `
      <div class="matching-overall">
        <div class="matching-score-circle">
          <span class="matching-score-value">${overallScore}</span>
          <span class="matching-score-label">匹配度</span>
        </div>
        <div class="matching-score-info">
          <p>${overallScore >= 80 ? '🎉 优秀匹配！您的经历与岗位高度契合' :
             overallScore >= 60 ? '👍 良好匹配！建议进一步优化经历描述' :
             overallScore >= 40 ? '💪 一般匹配！需要加强相关技能展示' :
             '📝 匹配度较低！建议调整求职方向或补充相关经历'}</p>
        </div>
      </div>

      <div class="matching-details">
        <h3>📊 经历匹配详情</h3>
        <div class="matching-list">
          ${results.map((result, index) => `
            <div class="matching-item">
              <div class="matching-item-header">
                <span class="matching-item-rank">#${index + 1}</span>
                <span class="matching-item-company">${result.experience.company}</span>
                <span class="matching-item-score" style="color: ${getScoreColor(result.score)}">${result.score}分</span>
              </div>
              <div class="matching-item-role">${result.experience.role}</div>
              <div class="matching-item-keywords">
                <span class="matching-item-label">匹配关键词：</span>
                ${result.matchedKeywords.length > 0 ? 
                  result.matchedKeywords.map(kw => `<span class="matching-keyword matched">${kw}</span>`).join('') : 
                  '<span style="color: #999;">无匹配关键词</span>'}
              </div>
              ${result.suggestions.length > 0 ? `
              <div class="matching-item-suggestions">
                <span class="matching-item-label">优化建议：</span>
                <ul>
                  ${result.suggestions.map(s => `<li>${s}</li>`).join('')}
                </ul>
              </div>
              ` : ''}
            </div>
          `).join('')}
        </div>
      </div>
    `;

    container.style.display = 'block';
  }

  function getScoreColor(score) {
    if (score >= 80) return '#22c55e';
    if (score >= 60) return '#eab308';
    if (score >= 40) return '#f97316';
    return '#ef4444';
  }

  function setupEventListeners() {
    const calculateBtn = document.getElementById('calculateMatchBtn');
    if (calculateBtn) calculateBtn.addEventListener('click', calculateMatching);
  }

  return {
    init,
    calculateMatching
  };
})();

window.MatchingModule = MatchingModule;
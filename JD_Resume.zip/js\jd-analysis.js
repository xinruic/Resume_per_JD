const JdAnalysisModule = (function() {
  const STORAGE_KEY = 'jd_data';
  const STORAGE_KEY_KEYWORDS = 'jd_keywords';
  
  let jdData = {};
  let jdKeywords = [];

  function init() {
    loadData();
    setupEventListeners();
  }

  function loadData() {
    jdData = Utils.storage.get(STORAGE_KEY, {});
    jdKeywords = Utils.storage.get(STORAGE_KEY_KEYWORDS, []);
    window.jdData = jdData;
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, jdData);
    Utils.storage.set(STORAGE_KEY_KEYWORDS, jdKeywords);
    window.jdData = jdData;
  }

  function analyzeJD() {
    const input = document.getElementById('jdInput');
    if (!input) return;

    const jdText = input.value.trim();
    if (!jdText) {
      Utils.showToast('请输入JD内容', 'error');
      return;
    }

    const btn = document.getElementById('analyzeJdBtn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '解析中...';

    try {
      const result = parseJDContent(jdText);
      displayAnalysis(result);
      Utils.showToast('JD解析完成', 'success');
    } catch (error) {
      console.error('JD解析失败:', error);
      Utils.showToast('解析失败，请重试', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = originalText;
    }
  }

  function parseJDContent(text) {
    const skills = [];
    const softSkills = [];
    const requirements = [];
    
    const skillKeywords = ['精通', '熟练', '掌握', '了解', '熟悉'];
    const softSkillKeywords = ['沟通', '协调', '团队', '协作', '责任心', '抗压', '学习'];
    
    const lines = text.split('\n').filter(line => line.trim());
    
    lines.forEach(line => {
      const trimmedLine = line.trim();
      
      if (trimmedLine.includes('岗位职责') || trimmedLine.includes('职责描述')) {
        requirements.push({ type: 'responsibility', content: trimmedLine });
      } else if (trimmedLine.includes('任职要求') || trimmedLine.includes('岗位要求')) {
        requirements.push({ type: 'requirement', content: trimmedLine });
      }
      
      skillKeywords.forEach(keyword => {
        if (trimmedLine.includes(keyword)) {
          const match = trimmedLine.match(new RegExp(`${keyword}[：:]?\\s*([^。！？；\\n]+)`));
          if (match) {
            skills.push(...match[1].split(/[,，、]/).map(s => s.trim()).filter(s => s.length > 2));
          }
        }
      });
      
      softSkillKeywords.forEach(keyword => {
        if (trimmedLine.includes(keyword)) {
          if (!softSkills.includes(keyword)) {
            softSkills.push(keyword);
          }
        }
      });
    });

    return {
      jobTitle: extractJobTitle(text),
      skills: [...new Set(skills)].slice(0, 10),
      softSkills: [...new Set(softSkills)].slice(0, 5),
      requirements: requirements.slice(0, 5),
      summary: generateSummary(text)
    };
  }

  function extractJobTitle(text) {
    const lines = text.split('\n').filter(line => line.trim());
    if (lines.length > 0) {
      return lines[0].trim().substring(0, 20);
    }
    return '未识别职位';
  }

  function generateSummary(text) {
    return `该岗位对${jdKeywords.length > 0 ? jdKeywords.slice(0, 3).join('、') : '专业技能'}有较高要求，注重${jdData.softSkills ? jdData.softSkills.slice(0, 2).join('和') : '综合能力'}。`;
  }

  function displayAnalysis(result) {
    jdData = result;
    jdKeywords = [...result.skills, ...result.softSkills];
    saveData();

    const jdAnalysisDiv = document.getElementById('jdAnalysis');
    const resultContainer = document.getElementById('jdAnalysisResult');
    
    if (!jdAnalysisDiv || !resultContainer) return;

    resultContainer.innerHTML = `
      <div class="jd-analysis-section">
        <h3>📋 职位信息</h3>
        <div class="jd-info-item">
          <span class="jd-info-label">职位名称：</span>
          <span class="jd-info-value">${result.jobTitle}</span>
        </div>
        <div class="jd-info-item">
          <span class="jd-info-label">分析摘要：</span>
          <span class="jd-info-value">${result.summary}</span>
        </div>
      </div>

      <div class="jd-analysis-section">
        <h3>🛠️ 专业技能要求</h3>
        <div class="jd-skills">
          ${result.skills.map(skill => `
            <span class="jd-skill-tag">${skill}</span>
          `).join('')}
        </div>
      </div>

      <div class="jd-analysis-section">
        <h3>💬 软技能要求</h3>
        <div class="jd-skills">
          ${result.softSkills.map(skill => `
            <span class="jd-skill-tag">${skill}</span>
          `).join('')}
        </div>
      </div>

      <div class="jd-analysis-section">
        <h3>📝 关键要求</h3>
        <ul class="jd-requirements">
          ${result.requirements.map(req => `
            <li>${req.content}</li>
          `).join('')}
        </ul>
      </div>
    `;

    jdAnalysisDiv.style.display = 'block';
  }

  async function fetchJDFromUrl() {
    const urlInput = document.getElementById('jdUrl');
    if (!urlInput) return;

    const url = urlInput.value.trim();
    if (!url) {
      Utils.showToast('请输入JD链接', 'error');
      return;
    }

    if (!Utils.isValidUrl(url)) {
      Utils.showToast('请输入有效的URL', 'error');
      return;
    }

    const btn = document.getElementById('fetchJdBtn');
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = '获取中...';

    try {
      Utils.showToast('正在获取JD内容，请稍候...', 'info');
      
      setTimeout(() => {
        Utils.showToast('无法从该链接提取内容，请手动复制粘贴', 'warning');
        btn.disabled = false;
        btn.textContent = originalText;
      }, 2000);
    } catch (error) {
      Utils.showToast('获取失败，请手动输入', 'error');
      btn.disabled = false;
      btn.textContent = originalText;
    }
  }

  function clearJD() {
    const input = document.getElementById('jdInput');
    const result = document.getElementById('jdAnalysisResult');
    
    if (input) input.value = '';
    if (result) result.style.display = 'none';
    
    jdData = {};
    jdKeywords = [];
    saveData();
    
    Utils.showToast('已清除JD内容', 'success');
  }

  function setupEventListeners() {
    const analyzeBtn = document.getElementById('analyzeJdBtn');
    if (analyzeBtn) analyzeBtn.addEventListener('click', analyzeJD);

    const fetchBtn = document.getElementById('fetchJdBtn');
    if (fetchBtn) fetchBtn.addEventListener('click', fetchJDFromUrl);

    const clearBtn = document.getElementById('clearJdBtn');
    if (clearBtn) clearBtn.addEventListener('click', clearJD);
  }

  function getJdData() {
    return { ...jdData };
  }

  function getJdKeywords() {
    return [...jdKeywords];
  }

  return {
    init,
    analyzeJD,
    fetchJDFromUrl,
    clearJD,
    getJdData,
    getJdKeywords
  };
})();

window.JdAnalysisModule = JdAnalysisModule;
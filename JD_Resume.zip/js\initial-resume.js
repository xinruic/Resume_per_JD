const InitialResumeModule = (function() {
  const STORAGE_KEY = 'initial_resumes';
  
  let resumes = {};
  let currentTab = null;

  function init() {
    loadData();
    setupEventListeners();
  }

  function loadData() {
    resumes = Utils.storage.get(STORAGE_KEY, {});
    window.currentResumes = resumes;
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, resumes);
    window.currentResumes = resumes;
  }

  function generateAllResumes() {
    const directions = CareerDirectionModule.getDirections();
    const experiences = ExperienceModule.getExperiences();

    if (directions.length === 0) {
      Utils.showToast('请先在"求职方向"栏目添加目标岗位方向', 'error');
      return;
    }

    if (experiences.length === 0) {
      Utils.showToast('请先添加简历经历', 'error');
      return;
    }

    const btn = document.getElementById('generateAllResumesBtn');
    btn.disabled = true;
    btn.textContent = '生成中...';

    try {
      resumes = {};

      directions.forEach(direction => {
        const workExperiences = experiences.filter(e => e.type === 'work');
        const eduExperiences = experiences.filter(e => e.type === 'education');

        const summary = `具有${workExperiences.length}年相关工作经验，专注于${direction}领域。能够独立完成项目开发和团队协作，具备良好的沟通能力和问题解决能力。`;

        resumes[direction] = {
          direction,
          summary,
          workExperiences: workExperiences.map(e => ({ ...e })),
          educations: eduExperiences.map(e => ({ ...e })),
          timestamp: Date.now()
        };
      });

      saveData();
      renderTabs();
      Utils.showToast(`成功生成${directions.length}份初版简历`, 'success');
    } catch (error) {
      console.error('生成简历失败:', error);
      Utils.showToast('生成失败，请重试', 'error');
    } finally {
      btn.disabled = false;
      btn.textContent = '一键生成所有方向简历';
    }
  }

  function renderTabs() {
    const container = document.getElementById('initialResumeContainer');
    const tabsContainer = document.getElementById('resumeTabsContainer');
    const tabs = document.getElementById('resumeTabs');
    const emptyState = document.getElementById('initialResumeEmpty');

    if (!container || !tabsContainer || !tabs) return;

    const directions = Object.keys(resumes);

    if (directions.length === 0) {
      tabsContainer.style.display = 'none';
      if (emptyState) emptyState.style.display = 'block';
      return;
    }

    tabsContainer.style.display = 'block';
    if (emptyState) emptyState.style.display = 'none';

    tabs.innerHTML = directions.map((dir, index) => `
      <button class="resume-tab-btn ${index === 0 ? 'active' : ''}" onclick="InitialResumeModule.switchTab('${dir}')">
        ${dir}
      </button>
    `).join('');

    currentTab = directions[0];
    renderContent(currentTab);
  }

  function switchTab(direction) {
    currentTab = direction;
    
    document.querySelectorAll('.resume-tab-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.querySelector(`.resume-tab-btn[onclick="InitialResumeModule.switchTab('${direction}')"]`).classList.add('active');

    renderContent(direction);
  }

  function renderContent(direction) {
    const resume = resumes[direction];
    if (!resume) return;

    const contentArea = document.getElementById('resumeContentArea');
    if (!contentArea) return;

    const workExperiences = Array.isArray(resume.workExperiences) ? resume.workExperiences : [];
    const educations = Array.isArray(resume.educations) ? resume.educations : [];

    let workHtml = workExperiences.length > 0 ? workExperiences.map((exp, idx) => `
      <div class="resume-item">
        <div class="resume-item-header">
          <span class="resume-item-company">${exp.company || '未填写公司'}</span>
          <span class="resume-item-date">${exp.startDate || ''} - ${exp.endDate || ''}</span>
        </div>
        <div class="resume-item-role">${exp.role || '未填写职位'}</div>
        <div class="resume-item-actions">
          <button class="btn btn-xs btn-outline" onclick="InitialResumeModule.polishExperience('${direction}', 'work', ${idx})">AI润色</button>
        </div>
        <div class="resume-item-desc" contenteditable="true" onblur="InitialResumeModule.saveEdit('${direction}', 'work-${idx}-desc', this.innerText)">
          ${exp.description || '暂无描述'}
        </div>
      </div>
    `).join('') : '<p style="color: #999;">暂无工作经历</p>';

    let eduHtml = educations.length > 0 ? educations.map((edu, idx) => `
      <div class="resume-item">
        <div class="resume-item-header">
          <span class="resume-item-company">${edu.company || '未填写学校'}</span>
          <span class="resume-item-date">${edu.startDate || ''} - ${edu.endDate || ''}</span>
        </div>
        <div class="resume-item-role">${edu.role || '未填写专业'}</div>
        <div class="resume-item-desc" contenteditable="true" onblur="InitialResumeModule.saveEdit('${direction}', 'edu-${idx}-desc', this.innerText)">
          ${edu.description || ''}
        </div>
      </div>
    `).join('') : '<p style="color: #999;">暂无教育背景</p>';

    contentArea.innerHTML = `
      <div class="resume-editor">
        <div class="resume-editor-header">
          <div class="resume-editor-title">${direction}方向简历</div>
          <div class="resume-editor-actions">
            <button class="btn btn-sm btn-primary" onclick="InitialResumeModule.downloadWord('${direction}')">下载Word</button>
            <button class="btn btn-sm btn-secondary" onclick="InitialResumeModule.refresh('${direction}')">刷新</button>
          </div>
        </div>
        <div class="resume-preview">
          <div class="resume-section">
            <div class="resume-section-title">求职意向</div>
            <div class="resume-item">
              <div class="resume-item-desc" contenteditable="true" onblur="InitialResumeModule.saveEdit('${direction}', 'summary', this.innerText)">
                ${resume.summary || ''}
              </div>
            </div>
          </div>
          <div class="resume-section">
            <div class="resume-section-title">工作经历</div>
            ${workHtml}
          </div>
          <div class="resume-section">
            <div class="resume-section-title">教育背景</div>
            ${eduHtml}
          </div>
        </div>
      </div>
    `;
  }

  function saveEdit(direction, field, value) {
    const resume = resumes[direction];
    if (!resume) return;

    if (field === 'summary') {
      resume.summary = value;
    } else {
      const match = field.match(/(work|edu)-(\d+)-desc/);
      if (match) {
        const type = match[1];
        const index = parseInt(match[2]);
        
        const experiences = type === 'work' ? 
          (Array.isArray(resume.workExperiences) ? resume.workExperiences : []) :
          (Array.isArray(resume.educations) ? resume.educations : []);
        
        if (experiences[index]) {
          experiences[index].description = value;
        }
      }
    }

    saveData();
  }

  function polishExperience(direction, type, index) {
    const resume = resumes[direction];
    if (!resume) return;

    const experiences = type === 'work' ? 
      (Array.isArray(resume.workExperiences) ? resume.workExperiences : []) :
      (Array.isArray(resume.educations) ? resume.educations : []);

    if (index >= experiences.length) return;

    const exp = experiences[index];
    const originalText = exp.description || '';

    if (!originalText.trim()) {
      Utils.showToast('请先填写经历描述', 'error');
      return;
    }

    Utils.showToast('正在AI润色...', 'info');

    const polishedText = polishResumeText(originalText, direction);
    experiences[index].description = polishedText;
    saveData();
    renderContent(direction);
    Utils.showToast('润色完成！', 'success');
  }

  function polishResumeText(text, targetSkill) {
    const polishRules = {
      '产品经理': [
        { regex: /负责|参与/g, replace: '主导' },
        { regex: /完成/g, replace: '交付' },
        { regex: /项目/g, replace: '产品项目' },
        { regex: /需求/g, replace: '产品需求' },
        { regex: /设计/g, replace: '产品设计' }
      ],
      'AI工程师': [
        { regex: /负责|参与/g, replace: '主导研发' },
        { regex: /模型/g, replace: '深度学习模型' },
        { regex: /训练/g, replace: '模型训练与调优' },
        { regex: /部署/g, replace: '模型部署与上线' }
      ],
      'Agent开发': [
        { regex: /开发/g, replace: 'Agent开发与集成' },
        { regex: /设计/g, replace: '智能体架构设计' },
        { regex: /对话/g, replace: '多轮对话' },
        { regex: /工具/g, replace: '工具调用与扩展' }
      ]
    };

    let polished = text;
    const rules = polishRules[targetSkill] || [];

    rules.forEach(rule => {
      polished = polished.replace(rule.regex, rule.replace);
    });

    return polished;
  }

  function refresh(direction) {
    const experiences = ExperienceModule.getExperiences();
    const resume = resumes[direction];
    
    if (resume) {
      resume.workExperiences = experiences.filter(e => e.type === 'work').map(e => ({ ...e }));
      resume.educations = experiences.filter(e => e.type === 'education').map(e => ({ ...e }));
      saveData();
      renderContent(direction);
      Utils.showToast('已从经历库刷新', 'success');
    }
  }

  function downloadWord(direction) {
    const resume = resumes[direction];
    if (!resume) {
      Utils.showToast('请先生成简历', 'error');
      return;
    }

    const workExperiences = Array.isArray(resume.workExperiences) ? resume.workExperiences : [];
    const educations = Array.isArray(resume.educations) ? resume.educations : [];

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: SimSun, serif; max-width: 800px; margin: 0 auto; padding: 40px; }
          .section-title { font-size: 16px; font-weight: bold; border-bottom: 2px solid #333; margin: 20px 0 10px; padding-bottom: 5px; }
          .item { margin: 15px 0; }
          .item-header { display: flex; justify-content: space-between; }
          .company { font-weight: bold; }
          .date { color: #666; font-size: 14px; }
          .role { color: #444; margin: 5px 0; }
          .desc { line-height: 1.8; font-size: 14px; }
          .summary { font-size: 14px; line-height: 1.8; }
        </style>
      </head>
      <body>
        <h1 style="text-align: center; font-size: 24px;">${direction}方向简历</h1>
        <div class="section-title">求职意向</div>
        <div class="summary">${resume.summary || ''}</div>
        <div class="section-title">工作经历</div>
        ${workExperiences.map(exp => `
          <div class="item">
            <div class="item-header">
              <span class="company">${exp.company || ''}</span>
              <span class="date">${exp.startDate || ''} - ${exp.endDate || ''}</span>
            </div>
            <div class="role">${exp.role || ''}</div>
            <div class="desc">${exp.description || ''}</div>
          </div>
        `).join('')}
        <div class="section-title">教育背景</div>
        ${educations.map(edu => `
          <div class="item">
            <div class="item-header">
              <span class="company">${edu.company || ''}</span>
              <span class="date">${edu.startDate || ''} - ${edu.endDate || ''}</span>
            </div>
            <div class="role">${edu.role || ''}</div>
            <div class="desc">${edu.description || ''}</div>
          </div>
        `).join('')}
      </body>
      </html>
    `;

    try {
      const blob = new Blob([htmlContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${direction}_初版简历.docx`;
      a.click();
      URL.revokeObjectURL(url);
      Utils.showToast('Word文档已下载', 'success');
    } catch (error) {
      Utils.showToast('下载失败', 'error');
    }
  }

  function setupEventListeners() {
    const generateBtn = document.getElementById('generateAllResumesBtn');
    if (generateBtn) generateBtn.addEventListener('click', generateAllResumes);
  }

  function getResume(direction) {
    return resumes[direction] || null;
  }

  function getAllResumes() {
    return { ...resumes };
  }

  return {
    init,
    generateAllResumes,
    switchTab,
    saveEdit,
    polishExperience,
    refresh,
    downloadWord,
    getResume,
    getAllResumes
  };
})();

window.InitialResumeModule = InitialResumeModule;
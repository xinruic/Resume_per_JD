document.addEventListener('DOMContentLoaded', () => {
  console.log('Initializing JD Resume Application...');

  CareerDirectionModule.init();
  ExperienceModule.init();
  InitialResumeModule.init();
  JdAnalysisModule.init();
  MatchingModule.init();
  TargetedResumeModule.init();

  setupTabNavigation();
  restoreLastTab();

  console.log('All modules initialized successfully!');
});

function setupTabNavigation() {
  const navBtns = document.querySelectorAll('.nav-btn');
  
  navBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const tabName = btn.dataset.tab;
      switchTab(tabName);
      saveLastTab(tabName);
    });
  });
}

function switchTab(tabName) {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.classList.remove('active');
  });
  document.querySelector(`[data-tab="${tabName}"]`).classList.add('active');

  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.remove('active');
  });
  document.getElementById(tabName).classList.add('active');

  if (tabName === 'matching') {
    MatchingModule.calculateMatching();
  }
}

function saveLastTab(tabName) {
  localStorage.setItem('lastTab', tabName);
}

function restoreLastTab() {
  const lastTab = localStorage.getItem('lastTab');
  if (lastTab && document.getElementById(lastTab)) {
    switchTab(lastTab);
  }
}
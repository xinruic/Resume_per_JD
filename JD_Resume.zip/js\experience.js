const ExperienceModule = (function() {
  const STORAGE_KEY = 'experiences';
  
  let experiences = [];
  let currentEditingId = null;

  function init() {
    loadData();
    renderList();
    setupEventListeners();
  }

  function loadData() {
    experiences = Utils.storage.get(STORAGE_KEY, getSampleData());
    window.experiences = experiences;
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, experiences);
    window.experiences = experiences;
  }

  function getSampleData() {
    return [
      {
        id: '1',
        type: 'work',
        company: '某科技公司',
        role: '高级产品经理',
        startDate: '2020-06',
        endDate: '2024-12',
        description: '负责公司核心产品的规划与设计，主导多个重大项目的迭代优化。带领团队完成产品从0到1的建设，用户量增长200%。',
        skills: '产品规划、需求分析、用户体验、项目管理'
      },
      {
        id: '2',
        type: 'work',
        company: '某互联网公司',
        role: '产品经理',
        startDate: '2018-03',
        endDate: '2020-05',
        description: '负责电商平台的功能迭代，优化用户购物流程，提升转化率15%。',
        skills: '电商产品、数据运营、A/B测试'
      },
      {
        id: '3',
        type: 'education',
        company: '某大学',
        role: '计算机科学与技术',
        degree: '本科',
        startDate: '2014-09',
        endDate: '2018-06',
        description: '',
        courses: '数据结构、算法设计、数据库原理、人工智能'
      }
    ];
  }

  function renderList() {
    const list = document.getElementById('expList');
    if (!list) return;

    if (experiences.length === 0) {
      list.innerHTML = `
        <div class="empty-state">
          <div class="empty-state-icon" aria-hidden="true">📝</div>
          <h3>暂无经历记录</h3>
          <p>点击上方按钮添加您的工作、实习、项目等经历，或点击"粘贴简历"导入Word文档内容</p>
        </div>
      `;
      return;
    }

    list.innerHTML = experiences.map(exp => `
      <div class="exp-item" data-exp-id="${exp.id}" onclick="ExperienceModule.selectExperience('${exp.id}')">
        <div class="exp-item-header">
          <span class="exp-item-type">${getTypeLabel(exp.type)}</span>
          <span class="exp-item-company">${exp.company || '未填写公司'}</span>
        </div>
        <div class="exp-item-role">${exp.role || '未填写职位'}</div>
        <div class="exp-item-date">${exp.startDate || ''} - ${exp.endDate || ''}</div>
        <div class="exp-item-desc">${exp.description ? exp.description.substring(0, 80) + '...' : '暂无描述'}</div>
        <div class="exp-item-actions">
          <button class="btn btn-sm btn-primary" onclick="event.stopPropagation(); ExperienceModule.editExperience('${exp.id}')">编辑</button>
          <button class="btn btn-sm btn-danger" onclick="event.stopPropagation(); ExperienceModule.deleteExperience('${exp.id}')">删除</button>
        </div>
      </div>
    `).join('');
  }

  function getTypeLabel(type) {
    const labels = {
      work: '工作经历',
      education: '教育背景',
      project: '项目经验',
      skills: '专业技能',
      internship: '实习经历'
    };
    return labels[type] || type;
  }

  function selectExperience(expId) {
    document.querySelectorAll('.exp-item').forEach(item => {
      item.classList.remove('active');
      item.classList.remove('dimmed');
    });

    const selected = document.querySelector(`.exp-item[data-exp-id="${expId}"]`);
    if (selected) {
      selected.classList.add('active');
    }
  }

  function addExperience() {
    currentEditingId = null;
    openEditModal();
  }

  function editExperience(expId) {
    currentEditingId = expId;
    openEditModal();
  }

  function deleteExperience(expId) {
    if (!confirm('确定要删除这条经历吗？')) return;
    
    const index = experiences.findIndex(e => e.id === expId);
    if (index !== -1) {
      experiences.splice(index, 1);
      saveData();
      renderList();
      Utils.showToast('已删除经历', 'success');
    }
  }

  function openEditModal() {
    const modal = document.getElementById('editModal');
    if (!modal) return;

    const exp = currentEditingId ? experiences.find(e => e.id === currentEditingId) : null;
    const title = document.getElementById('editModalTitle');
    
    if (title) {
      title.textContent = currentEditingId ? '编辑经历' : '添加经历';
    }

    document.getElementById('expType').value = exp ? exp.type : 'work';
    document.getElementById('expCompany').value = exp ? exp.company : '';
    document.getElementById('expRole').value = exp ? exp.role : '';
    document.getElementById('expDegree').value = exp ? exp.degree : '本科';
    document.getElementById('expStart').value = exp ? exp.startDate : '';
    document.getElementById('expEnd').value = exp ? exp.endDate : '';
    document.getElementById('expDesc').value = exp ? exp.description : '';
    document.getElementById('expSkills').value = exp ? exp.skills : '';
    document.getElementById('expAchievements').value = exp ? exp.achievements : '';
    document.getElementById('expCourses').value = exp ? exp.courses : '';

    toggleFormFields(exp ? exp.type : 'work');
    modal.style.display = 'block';
  }

  function toggleFormFields(type) {
    const degreeGroup = document.getElementById('degreeGroup');
    const skillsGroup = document.getElementById('skillsGroup');
    const coursesGroup = document.getElementById('coursesGroup');
    const roleLabel = document.querySelector('label[for="expRole"]');
    const descLabel = document.querySelector('label[for="expDesc"]');

    if (degreeGroup) degreeGroup.style.display = type === 'education' ? 'block' : 'none';
    if (skillsGroup) skillsGroup.style.display = type !== 'education' ? 'block' : 'none';
    if (coursesGroup) coursesGroup.style.display = type === 'education' ? 'block' : 'none';
    
    if (roleLabel) {
      roleLabel.textContent = type === 'education' ? '专业' : '职位';
    }
    if (descLabel) {
      descLabel.textContent = type === 'education' ? '主要课程' : '描述';
    }
  }

  function closeEditModal() {
    const modal = document.getElementById('editModal');
    if (modal) {
      modal.style.display = 'none';
    }
    currentEditingId = null;
  }

  function saveExperience() {
    const id = currentEditingId || Utils.generateId();
    const type = document.getElementById('expType').value;
    const company = document.getElementById('expCompany').value.trim();
    const degree = type === 'education' ? document.getElementById('expDegree').value : '';
    const role = type === 'education' 
      ? document.getElementById('expDesc').value.trim() 
      : document.getElementById('expRole').value.trim();
    const startDate = document.getElementById('expStart').value;
    const endDate = document.getElementById('expEnd').value;
    const description = type === 'education' ? '' : document.getElementById('expDesc').value.trim();
    const skills = type === 'education' ? '' : document.getElementById('expSkills').value.trim();
    const achievements = document.getElementById('expAchievements').value.trim();
    const courses = type === 'education' ? document.getElementById('expCourses').value.trim() : '';

    if (type !== 'skills' && (!company || !role || !startDate)) {
      Utils.showToast('请填写必填项', 'error');
      return;
    }

    const exp = {
      id,
      type,
      company,
      role,
      degree,
      startDate,
      endDate,
      description,
      skills,
      achievements,
      courses
    };

    if (currentEditingId) {
      const index = experiences.findIndex(e => e.id === id);
      if (index !== -1) {
        experiences[index] = exp;
      }
    } else {
      experiences.unshift(exp);
    }

    saveData();
    renderList();
    closeEditModal();
    Utils.showToast(currentEditingId ? '已更新经历' : '已添加经历', 'success');
  }

  function togglePasteSection() {
    const pasteSection = document.getElementById('pasteSection');
    const pasteResumeBtn = document.getElementById('pasteResumeBtn');
    const textInput = document.getElementById('resumeTextInput');
    const parseBtn = document.getElementById('parseResumeBtn');

    if (!pasteSection || !pasteResumeBtn) return;

    const isHidden = pasteSection.style.display === 'none' || pasteSection.style.display === '';

    if (isHidden) {
      pasteSection.style.display = 'block';
      if (textInput) textInput.style.display = 'block';
      if (parseBtn) parseBtn.style.display = 'block';
      pasteResumeBtn.textContent = '收起粘贴';
      
      setTimeout(() => {
        pasteSection.scrollIntoView({ behavior: 'smooth', block: 'center' });
        if (textInput) textInput.focus();
      }, 100);
    } else {
      pasteSection.style.display = 'none';
      pasteResumeBtn.textContent = '粘贴简历';
    }
  }

  async function parseResumeText() {
    const textInput = document.getElementById('resumeTextInput');
    const parseBtn = document.getElementById('parseResumeBtn');
    
    if (!textInput || !parseBtn) return;

    const text = textInput.value.trim();
    if (!text) {
      Utils.showToast('请输入简历内容', 'error');
      return;
    }

    parseBtn.disabled = true;
    parseBtn.textContent = '解析中...';

    try {
      const parsedExperiences = parseResumeContent(text);
      
      if (parsedExperiences.length === 0) {
        Utils.showToast('未能识别到有效的经历信息，请手动添加', 'info');
        return;
      }

      experiences = [...parsedExperiences, ...experiences];
      saveData();
      renderList();
      Utils.showToast(`成功解析${parsedExperiences.length}条经历`, 'success');

      textInput.value = '';
      document.getElementById('pasteSection').style.display = 'none';
      document.getElementById('pasteResumeBtn').textContent = '粘贴简历';
    } catch (error) {
      console.error('解析失败:', error);
      Utils.showToast('解析失败，请重试', 'error');
    } finally {
      parseBtn.disabled = false;
      parseBtn.textContent = '解析简历';
    }
  }

  function parseResumeContent(text) {
    const result = [];
    const lines = text.split('\n').filter(line => line.trim());
    
    let currentExp = null;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      
      if (isDateLine(line)) {
        if (currentExp && (currentExp.company || currentExp.role)) {
          result.push(currentExp);
        }
        currentExp = {
          id: Utils.generateId(),
          type: 'work',
          company: '',
          role: '',
          startDate: '',
          endDate: '',
          description: '',
          skills: ''
        };
        
        const dates = extractDates(line);
        currentExp.startDate = dates[0];
        currentExp.endDate = dates[1];
      } else if (currentExp) {
        if (!currentExp.company) {
          currentExp.company = line;
        } else if (!currentExp.role) {
          currentExp.role = line;
        } else {
          currentExp.description += (currentExp.description ? '\n' : '') + line;
        }
      }
    }

    if (currentExp && (currentExp.company || currentExp.role)) {
      result.push(currentExp);
    }

    return result;
  }

  function isDateLine(line) {
    return /\d{4}[-/年]\d{1,2}[-/月]?\s*[-~至]\s*\d{4}[-/年]\d{1,2}[-/月]?/.test(line) ||
           /\d{4}[-/年]\d{1,2}[-/月]?\s*[-~至]\s*至今/.test(line);
  }

  function extractDates(line) {
    const match = line.match(/(\d{4}[-/年]\d{1,2}[-/月]?)\s*[-~至]\s*(至今|\d{4}[-/年]\d{1,2}[-/月]?)/);
    if (match) {
      return [formatDateStr(match[1]), match[2] === '至今' ? '' : formatDateStr(match[2])];
    }
    return ['', ''];
  }

  function formatDateStr(dateStr) {
    const match = dateStr.match(/(\d{4})[-/年](\d{1,2})/);
    if (match) {
      return `${match[1]}-${match[2].padStart(2, '0')}`;
    }
    return dateStr;
  }

  function clearAllData() {
    if (!confirm('确定要清除所有经历数据吗？此操作不可恢复。')) return;
    
    experiences = [];
    saveData();
    renderList();
    Utils.showToast('已清除所有经历数据', 'success');
  }

  function setupEventListeners() {
    const addBtn = document.getElementById('addExpBtn');
    if (addBtn) addBtn.addEventListener('click', addExperience);

    const pasteBtn = document.getElementById('pasteResumeBtn');
    if (pasteBtn) pasteBtn.addEventListener('click', togglePasteSection);

    const parseBtn = document.getElementById('parseResumeBtn');
    if (parseBtn) parseBtn.addEventListener('click', parseResumeText);

    const closeModalBtn = document.getElementById('closeEditModal');
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeEditModal);

    const cancelBtn = document.getElementById('cancelEditBtn');
    if (cancelBtn) cancelBtn.addEventListener('click', closeEditModal);

    const saveBtn = document.getElementById('saveEditBtn');
    if (saveBtn) saveBtn.addEventListener('click', saveExperience);

    const clearBtn = document.getElementById('clearStorageBtn');
    if (clearBtn) clearBtn.addEventListener('click', clearAllData);

    const expTypeSelect = document.getElementById('expType');
    if (expTypeSelect) expTypeSelect.addEventListener('change', (e) => toggleFormFields(e.target.value));
  }

  function getExperiences() {
    return [...experiences];
  }

  return {
    init,
    addExperience,
    editExperience,
    deleteExperience,
    selectExperience,
    getExperiences
  };
})();

window.ExperienceModule = ExperienceModule;
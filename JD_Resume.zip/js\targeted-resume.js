const TargetedResumeModule = (function() {
  const STORAGE_KEY = 'targeted_resume';
  
  let targetedResume = null;

  function init() {
    loadData();
    setupEventListeners();
  }

  function loadData() {
    targetedResume = Utils.storage.get(STORAGE_KEY, null);
  }

  function saveData() {
    Utils.storage.set(STORAGE_KEY, targetedResume);
  }

  function generateTargetedResume() {
    try {
      const directions = CareerDirectionModule.getDirections();
      const jdData = JdAnalysisModule.getJdData();
      const jdKeywords = JdAnalysisModule.getJdKeywords();

      const matchedDirection = matchDirectionFromJD(directions, jdData);

      if (!matchedDirection) {
        Utils.showToast('请先在"求职方向"栏目添加目标岗位方向', 'error');
        return;
      }

      const initialResume = InitialResumeModule.getResume(matchedDirection);
      if (!initialResume) {
        Utils.showToast(`未找到"${matchedDirection}"方向的初版简历，请先生成初版简历`, 'error');
        return;
      }

      if (jdKeywords.length === 0) {
        Utils.showToast('请先在"JD解析"栏目分析岗位需求', 'error');
        return;
      }

      const optimizedResume = optimizeResumeForJD(initialResume, jdKeywords);

      targetedResume = {
        ...optimizedResume,
        direction: matchedDirection,
        jdKeywords: jdKeywords,
        generatedAt: Date.now()
      };

      saveData();
      renderResume();

      document.getElementById('targetedResumeMatchInfo').style.display = 'block';
      document.getElementById('matchedDirection').textContent = matchedDirection;
      document.getElementById('jdKeywordsDisplay').textContent = jdKeywords.slice(0, 5).join('、');

      Utils.showToast(`成功生成"${matchedDirection}"方向的针对性简历`, 'success');
    } catch (error) {
      console.error('生成针对性简历失败:', error);
      Utils.showToast('生成失败，请重试', 'error');
    }
  }

  function matchDirectionFromJD(directions, jdData) {
    if (directions.length === 0) return null;
    if (!jdData || !jdData.jobTitle) return directions[0];

    const jobTitle = jdData.jobTitle.toLowerCase();

    const directionKeywords = {
      '产品经理': ['产品', 'product', 'pm'],
      'AI工程师': ['ai', '人工智能', '机器学习', '深度学习', '算法'],
      'Agent开发': ['agent', '智能体', '多模态', '对话', 'llm'],
      '前端开发': ['前端', 'frontend', 'web', 'react', 'vue'],
      '后端开发': ['后端', 'backend', 'server', 'java', 'python'],
      '数据分析': ['数据', 'data', '分析', 'analytics'],
      '测试工程师': ['测试', 'test', 'qa'],
      '运维工程师': ['运维', 'devops', 'ops']
    };

    let maxScore = 0;
    let bestMatch = directions[0];

    directions.forEach(tag => {
      const keywords = directionKeywords[tag] || [];
      let score = 0;
      keywords.forEach(keyword => {
        if (jobTitle.includes(keyword.toLowerCase())) {
          score++;
        }
      });
      if (score > maxScore) {
        maxScore = score;
        bestMatch = tag;
      }
    });

    return bestMatch;
  }

  function optimizeResumeForJD(resume, jdKeywords) {
    const optimized = { ...resume };

    if (Array.isArray(resume.workExperiences)) {
      optimized.workExperiences = resume.workExperiences.map(exp => ({
        ...exp,
        description: enhanceDescription(exp.description || '', jdKeywords)
      }));
    }

    if (resume.summary) {
      let newSummary = resume.summary;
      jdKeywords.slice(0, 3).forEach(keyword => {
        if (!newSummary.includes(keyword)) {
          newSummary += `，具备${keyword}能力`;
        }
      });
      optimized.summary = newSummary;
    }

    return optimized;
  }

  function enhanceDescription(text, keywords) {
    let enhanced = text;

    keywords.slice(0, 5).forEach(keyword => {
      if (!enhanced.includes(keyword)) {
        enhanced += `，具备${keyword}相关经验`;
      }
    });

    return enhanced;
  }

  function renderResume() {
    if (!targetedResume) return;

    const contentArea = document.getElementById('targetedResumeContent');
    if (!contentArea) return;

    const workExperiences = Array.isArray(targetedResume.workExperiences) ? targetedResume.workExperiences : [];
    const educations = Array.isArray(targetedResume.educations) ? targetedResume.educations : [];

    let workHtml = workExperiences.length > 0 ? workExperiences.map((exp, idx) => `
      <div class="resume-item">
        <div class="resume-item-header">
          <span class="resume-item-company">${exp.company || '未填写公司'}</span>
          <span class="resume-item-date">${exp.startDate || ''} - ${exp.endDate || ''}</span>
        </div>
        <div class="resume-item-role">${exp.role || '未填写职位'}</div>
        <div class="resume-item-desc">${exp.description || '暂无描述'}</div>
      </div>
    `).join('') : '<p style="color: #999;">暂无工作经历</p>';

    let eduHtml = educations.length > 0 ? educations.map((edu, idx) => `
      <div class="resume-item">
        <div class="resume-item-header">
          <span class="resume-item-company">${edu.company || '未填写学校'}</span>
          <span class="resume-item-date">${edu.startDate || ''} - ${edu.endDate || ''}</span>
        </div>
        <div class="resume-item-role">${edu.role || '未填写专业'}</div>
        <div class="resume-item-desc">${edu.description || ''}</div>
      </div>
    `).join('') : '<p style="color: #999;">暂无教育背景</p>';

    contentArea.innerHTML = `
      <div class="resume-editor">
        <div class="resume-editor-header">
          <div class="resume-editor-title">${targetedResume.direction} - 针对性简历</div>
        </div>
        <div class="resume-preview">
          <div class="resume-section">
            <div class="resume-section-title">求职意向</div>
            <div class="resume-item">
              <div class="resume-item-desc">${targetedResume.summary || ''}</div>
            </div>
          </div>
          <div class="resume-section">
            <div class="resume-section-title">工作经历</div>
            ${workHtml}
          </div>
          <div class="resume-section">
            <div class="resume-section-title">教育背景</div>
            ${eduHtml}
          </div>
          ${targetedResume.jdKeywords && targetedResume.jdKeywords.length > 0 ? `
          <div class="resume-section">
            <div class="resume-section-title">JD关键词匹配</div>
            <div class="resume-skills">
              ${targetedResume.jdKeywords.map(kw => `<span class="resume-skill">${kw}</span>`).join('')}
            </div>
          </div>
          ` : ''}
        </div>
      </div>
    `;

    document.getElementById('targetedResumePreview').style.display = 'block';
    document.getElementById('targetedResumeEmpty').style.display = 'none';
  }

  function downloadTargetedResumeWord() {
    if (!targetedResume) {
      Utils.showToast('请先生成针对性简历', 'error');
      return;
    }

    const workExperiences = Array.isArray(targetedResume.workExperiences) ? targetedResume.workExperiences : [];
    const educations = Array.isArray(targetedResume.educations) ? targetedResume.educations : [];

    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <style>
          body { font-family: SimSun, serif; max-width: 800px; margin: 0 auto; padding: 40px; }
          .section-title { font-size: 16px; font-weight: bold; border-bottom: 2px solid #333; margin: 20px 0 10px; padding-bottom: 5px; }
          .item { margin: 15px 0; }
          .item-header { display: flex; justify-content: space-between; }
          .company { font-weight: bold; }
          .date { color: #666; font-size: 14px; }
          .role { color: #444; margin: 5px 0; }
          .desc { line-height: 1.8; font-size: 14px; }
          .summary { font-size: 14px; line-height: 1.8; }
          .skills { margin-top: 10px; }
          .skill-tag { display: inline-block; padding: 4px 12px; background: #f0f0f0; border-radius: 4px; margin: 4px; font-size: 13px; }
        </style>
      </head>
      <body>
        <h1 style="text-align: center; font-size: 24px;">${targetedResume.direction} - 针对性简历</h1>
        <div class="section-title">求职意向</div>
        <div class="summary">${targetedResume.summary || ''}</div>
        <div class="section-title">工作经历</div>
        ${workExperiences.map(exp => `
          <div class="item">
            <div class="item-header">
              <span class="company">${exp.company || ''}</span>
              <span class="date">${exp.startDate || ''} - ${exp.endDate || ''}</span>
            </div>
            <div class="role">${exp.role || ''}</div>
            <div class="desc">${exp.description || ''}</div>
          </div>
        `).join('')}
        <div class="section-title">教育背景</div>
        ${educations.map(edu => `
          <div class="item">
            <div class="item-header">
              <span class="company">${edu.company || ''}</span>
              <span class="date">${edu.startDate || ''} - ${edu.endDate || ''}</span>
            </div>
            <div class="role">${edu.role || ''}</div>
            <div class="desc">${edu.description || ''}</div>
          </div>
        `).join('')}
        ${targetedResume.jdKeywords && targetedResume.jdKeywords.length > 0 ? `
        <div class="section-title">JD关键词匹配</div>
        <div class="skills">
          ${targetedResume.jdKeywords.map(kw => `<span class="skill-tag">${kw}</span>`).join('')}
        </div>
        ` : ''}
      </body>
      </html>
    `;

    try {
      const blob = new Blob([htmlContent], { type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${targetedResume.direction}_针对性简历.docx`;
      a.click();
      URL.revokeObjectURL(url);
      Utils.showToast('Word文档已下载', 'success');
    } catch (error) {
      console.error('下载Word失败:', error);
      Utils.showToast('下载失败', 'error');
    }
  }

  function setupEventListeners() {
    const generateBtn = document.getElementById('generateTargetedResumeBtn');
    if (generateBtn) generateBtn.addEventListener('click', generateTargetedResume);

    const downloadBtn = document.getElementById('downloadTargetedResumeWordBtn');
    if (downloadBtn) downloadBtn.addEventListener('click', downloadTargetedResumeWord);
  }

  return {
    init,
    generateTargetedResume,
    downloadTargetedResumeWord
  };
})();

window.TargetedResumeModule = TargetedResumeModule;